<?php 
    require('classes/class.config.php');
    $objetPix = new Intermediador;
?>
<?php
	$pag[1]     = "home/index.php";
	$pag[2]     = "views/pix/gerar.php";
	$pag[3]     = "views/pix/consultar.php";
	$pag[4]     = "views/vendas/listagem.php";
	$pag[5]     = "views/vendas/ver.venda.php";
	$pag[6]     = "user/dados.php";
	$pag[7]     = "views/configuracao_pagamento/config.php";
?>





