<?php
session_start(); 

include('config/conexao.php');
include('config/tabs.php');
?>
<script>

		CKEDITOR.on( 'instanceReady', function( evt ) {
			var editor = evt.editor;
			editor.setData( 'This editor has it\'s tabIndex set to <strong>' + editor.tabIndex + '</strong>' );

			// Apply focus class name.
			editor.on( 'focus', function() {
				editor.container.addClass( 'cke_focused' );
			});
			editor.on( 'blur', function() {
				editor.container.removeClass( 'cke_focused' );
			});

			// Put startup focus on the first editor in tab order.
			if ( editor.tabIndex == 1 )
				editor.focus();
		});

</script>
<script language="javascript">
function myfunction(objTextBox, SeparadorMilesimo, SeparadorDecimal, e){
    var sep = 0;
    var key = '';
    var i = j = 0;
    var len = len2 = 0;
    var strCheck = '0123456789';
    var aux = aux2 = '';
    var whichCode = (window.Event) ? e.which : e.keyCode;
    if (whichCode == 13) return true;
    key = String.fromCharCode(whichCode); // Valor para o código da Chave
    if (strCheck.indexOf(key) == -1) return false; // Chave inválida
    len = objTextBox.value.length;
    for(i = 0; i < len; i++)
        if ((objTextBox.value.charAt(i) != '0') && (objTextBox.value.charAt(i) != SeparadorDecimal)) break;
    aux = '';
    for(; i < len; i++)
        if (strCheck.indexOf(objTextBox.value.charAt(i))!=-1) aux += objTextBox.value.charAt(i);
    aux += key;
    len = aux.length;
    if (len == 0) objTextBox.value = '';
    if (len == 1) objTextBox.value = '0'+ SeparadorDecimal + '0' + aux;
    if (len == 2) objTextBox.value = '0'+ SeparadorDecimal + aux;
    if (len > 2) {
        aux2 = '';
        for (j = 0, i = len - 3; i >= 0; i--) {
            if (j == 3) {
                aux2 += SeparadorMilesimo;
                j = 0;
            }
            aux2 += aux.charAt(i);
            j++;
        }
        objTextBox.value = '';
        len2 = aux2.length;
        for (i = len2 - 1; i >= 0; i--)
        objTextBox.value += aux2.charAt(i);
        objTextBox.value += SeparadorDecimal + aux.substr(len - 2, len);
    }
    return false;
}
</script>
<?php if($_SESSION['usuario_id'] <> ''){ ?>
<?php
	$url = $_GET["url"];
		
    date_default_timezone_set('America/Sao_Paulo');
    $data_atual_hoje 		= date('Y-m-d');
    $atual		= strtotime($data_atual_hoje);
	
	if($total_pay > 0){
	    $pag[1]     = "home/index.php";
	} else {
        include('control_lista.php');
	}
	
    if(!empty($url)){
		error_reporting(0);
		ini_set("display_errors", 0 );
        if(file_exists($pag[$url])){
            include $pag[$url];
        }else{
            echo "<script>
            window.location.href='control.php?url=1';
            </script>";
		}
	}else{
        echo "<script>
            window.location.href='control.php?url=1';
        </script>";
	}
	include('blocos/modal_remover.php');
?>
<?php } else { ?>
    <script>
            window.location.href='https://<?php echo $host;?>/cleber/admin/';
        </script>
<?php } ?>
  
<script>
	initSample();
</script>
