<?php session_start(); ?>
<?php

// Conexão com banco de dados
$server = 'localhost';
$user   = 'u698743207_cadpix';
$pass   = '8=pW42AF[hf';
$db    = 'u698743207_cadpix';

$conexao = mysqli_connect($server, $user, $pass, $db);


?>