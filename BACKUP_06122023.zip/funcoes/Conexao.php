<?php
$servidor = 'localhost';
$usuario  = 'u698743207_administ';
$senha 	  = '8=pW42AF[hf';
$banco    = 'u698743207_administ';

// FUNCOES DO SISTEMA DE CADASTRO ###########

$nomesite  = 'CFSOLUCOESTECNOLOGICAS';
$urlmaster = 'https://cfsolucoestecnologicas.online'; // APENAS A URL PRINCIPAL SEM A BARRA NO FINAL ---- ----

date_default_timezone_set('America/Sao_Paulo');